# Barbára Lima
# Nicolas Nasário
# Victória Kallas

# classes começam com letra maiúscula
class DisciplinaModelo:
    def __init__(self, codigo, nome, carga_horaria, nome_professor):
        self.codigo = codigo
        self.nome = nome
        self.carga_horaria = carga_horaria
        self.nome_professor = nome_professor
        
        
        