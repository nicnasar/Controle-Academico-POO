# Barbára Lima
# Nicolas Nasário
# Victória Kallas

# classes começam com letra maiúscula
class AlunoModelo:
    def __init__(self, nome, cpf, idade, email, endereco):
        self.nome = nome
        self.cpf = cpf
        self.idade = idade
        self.email = email
        self.endereco = endereco
        
        