# Barbára Lima
# Nicolas Nasário
# Victória Kallas

# classes começam com letra maiúscula
class MatriculaModelo:
    def __init__(self, codigo_disciplina, cpf_aluno, data_matricula, horario_matricula):
        self.codigo_disciplina = codigo_disciplina
        self.cpf_aluno = cpf_aluno
        self.data_matricula = data_matricula
        self.horario_matricula = horario_matricula
        

    